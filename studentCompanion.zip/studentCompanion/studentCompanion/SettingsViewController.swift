//
//  SettingsViewController.swift
//  studentCompanion
//
//  Created by user256361 on 7/8/24.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var showPendingButton: UIButton!
    @IBOutlet weak var showCompletedButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func pendingB(_ sender: UIButton) {
        showAlert(message: "Sort by Pending Tasks")
    }
    
    @IBAction func completedB(_ sender: Any) {
        showAlert(message: "Sort by Completed Tasks")

    }
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
}
