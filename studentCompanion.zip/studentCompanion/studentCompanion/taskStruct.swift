//
//  taskStruct.swift
//  studentCompanion
//
//  Created by user256361 on 7/8/24.
//

import Foundation
import UIKit

struct Task {
    var title: String
    var description: String?
    var dueDate: Date
    var image: UIImage?
}

class TaskManager {
    
    static let shared = TaskManager()
    private var tasks: [Task] = []
    
    private init() {}
    
    func addTask(_ task: Task) {
        tasks.append(task)
    }
    
    func getTasks() -> [Task] {
        return tasks
    }
}

