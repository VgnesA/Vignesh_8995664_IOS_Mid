//
//  ViewController.swift
//  studentCompanion
//
//  Created by user256361 on 7/8/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

