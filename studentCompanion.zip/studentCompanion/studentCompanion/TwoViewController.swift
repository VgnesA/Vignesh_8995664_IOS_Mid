//
//  TwoViewController.swift
//  studentCompanion
//
//  Created by user256361 on 7/8/24.
//

import UIKit

class TwoViewController: UIViewController {
    
    @IBOutlet weak var status: UITextField!
    
    @IBOutlet weak var twoTitle: UITextField!
    
    @IBOutlet weak var twoDescription: UITextField!
    
    @IBOutlet weak var twoDue: UIDatePicker!
    
    @IBOutlet weak var imageTwo: UIImageView!
    
    @IBOutlet weak var backB: UIButton!
    
    
    var task: Task?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()

    }
    
    func updateUI() {
          if let task = task {
              twoTitle.text = task.title
              twoDescription.text = task.description
              twoDue.date = task.dueDate
              imageTwo.image = task.image
              if task.dueDate < Date() {
                  status.text = "Completed"
              }else{
                  status.text = "Pending"
              }
          }
      }
    
    
    @IBAction func backPage(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
  }

