//
//  CreateViewController.swift
//  studentCompanion
//
//  Created by user256361 on 7/8/24.
//

import UIKit

class CreateViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate  {
    
    @IBOutlet weak var titleText: UITextField!
    
    @IBOutlet weak var descriptionText: UITextField!
    
    @IBOutlet weak var dueDate: UIDatePicker!
    
    @IBOutlet weak var imagePickerView: UIPickerView!
    
    @IBOutlet weak var resetB: UIButton!
    
    @IBOutlet weak var submitB: UIButton!
    
    weak var delegate: CreateViewController?
   
    let imageArray: [(name: String, image: UIImage)] = [
        (name: "explore", image: UIImage(named:"explore")!),
        (name: "search", image: UIImage(named:"search")!),
        (name: "sports", image: UIImage(named:"sports")!)
    
    ]
    
    var selectedImage: UIImage?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            imagePickerView.dataSource = self
            imagePickerView.delegate = self
            

        }
        
    
    
   
        @IBAction func resetButton(_ sender: Any) {
            titleText.text = ""
            descriptionText.text = ""
            dueDate.date = Date()
            imagePickerView.selectRow(0, inComponent: 0, animated: false)

            // Reset imagePickerView to its default state
            // You might need to reload the data or reset the selection
        }
        
        @IBAction func submitButton(_ sender: Any) {
            guard let ctitle = titleText.text, !ctitle.isEmpty else {
                showAlert(message: "Title is required.")
                return
            }
            
            let task = Task(title: ctitle, description: descriptionText.text, dueDate: dueDate.date, image: nil)
            TaskManager.shared.addTask(task)
            
            showAlert(message: "Task created successfully!")
            
            // Optionally, dismiss the view controller
            navigationController?.popViewController(animated: true)
        }

        func showAlert(message: String) {
            let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
          return 1
      }
      
      func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
          return imageArray.count
      }
      
      // MARK: - UIPickerViewDelegate
      
      func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
          let imageView = UIImageView(image: imageArray[row].image)
          imageView.contentMode = .scaleAspectFit
          return imageView
      }
      
      func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
          selectedImage = imageArray[row].image
      }
  }
    
